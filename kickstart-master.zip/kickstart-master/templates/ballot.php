<div class="kickstart-ballot" data-post-id="<?php the_ID(); ?>">
	<div class="kickstart-vote up" data-vote-direction="up"></div>
	<div class="kickstart-vote down" data-vote-direction="down"></div>
	<div class="kickstart-score"><?php echo $this->get_score(); ?></div>
</div>